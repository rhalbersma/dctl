#include "DXP_MessageFactory.h"

class DXP_Test
{
public:
        static void Mesander_examples(void);
};
